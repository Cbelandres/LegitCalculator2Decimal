package com.example.bottomnav

data class Animal(
    var name: String,
    val imageResId: Int,
    var checked: Boolean
)
